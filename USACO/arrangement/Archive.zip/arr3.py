A = int(input())
B = int(input())
C = int(input())
D = A*B*C
D = str(D)
print(D)
for number in range(10):
    print(D.count(str(number)))


